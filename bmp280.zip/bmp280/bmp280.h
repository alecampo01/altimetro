#ifndef BMP280_H
#define BMP280_H

#include <Adafruit_BMP280.h>
#include "Sensor.h"

class BMP280 : public Sensor{
  public:
    BMP280();
    bool begin() override; 
    float readTemperature() override;
    float readPressure() override;
    float readAltitude() override;

  private:
    Adafruit_BMP280 bmp;
};

#endif // BM280_H
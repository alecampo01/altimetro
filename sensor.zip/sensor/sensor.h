#ifndef SENSOR_H
#define SENSOR_H

class Sensor{
  public:
    virtual bool begin() = 0;
    virtual float readTemperature() = 0;
    virtual float readPressure() = 0;
    virtual float readAltitude() = 0;
};

#endif // SENSOR_H